# -*- coding: utf-8 -*-
{
    'name': "Secuencia de productos en orden de venta",
    'author': "Elymar Alfaro",
    'category': 'Sales',
    'version': '17.1',
    'depends': ['sale', 'stock'],
    'data': [
        'views/product_template_views.xml',
        'views/sale_order_views.xml',
    ],

}
