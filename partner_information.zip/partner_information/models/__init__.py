from . import allergies
from . import axis_catalog
from . import partner_attachment
from . import preferred_substance
from . import psychiatric_diagnosis
from . import res_partner
from . import res_partner_relation
from . import res_partner_status


