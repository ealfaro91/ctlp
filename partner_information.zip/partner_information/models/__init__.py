from . import preferred_substance
from . import res_partner
from . import res_partner_relation
from . import res_partner_status


